package com.example.taiganights;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

public final class ModSounds {
    public static final SoundEvent BLIZZARD_WIND = register("blizzard.wind");
    public static final SoundEvent NIGHT_HOWL = register("night.howl");
    public static final SoundEvent NIGHT_OWL = register("night.owl");
    public static final SoundEvent AXE_CHOP = register("axe.chop");

    private static SoundEvent register(String name) {
        Identifier id = Identifier.fromNamespaceAndPath(TaigaNights.MOD_ID, name);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }

    /** Вызов нужен, чтобы класс загрузился и константы зарегистрировались. */
    public static void init() {}

    private ModSounds() {}
}
