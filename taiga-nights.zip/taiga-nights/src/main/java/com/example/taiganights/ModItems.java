package com.example.taiganights;

import java.util.List;
import java.util.function.Function;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Consumables;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.equipment.ArmorType;

public final class ModItems {
    /** Хвойный чай: отогревает и даёт «Тепло» на 2,5 минуты. */
    public static final Item SPRUCE_TEA = register("spruce_tea",
            p -> new WarmingItem(p, 20 * 150),
            new Item.Properties().stacksTo(16).usingConvertsTo(Items.BOWL)
                    .food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.4f).alwaysEdible().build(),
                            Consumables.DEFAULT_DRINK)
                    .component(DataComponents.LORE, lore("spruce_tea")));

    /** Таёжная похлёбка: сытная еда и «Тепло» на 4 минуты. */
    public static final Item TAIGA_STEW = register("taiga_stew",
            p -> new WarmingItem(p, 20 * 240),
            new Item.Properties().stacksTo(16).usingConvertsTo(Items.BOWL)
                    .food(new FoodProperties.Builder().nutrition(9).saturationModifier(0.8f).build(),
                            Consumables.DEFAULT_FOOD)
                    .component(DataComponents.LORE, lore("taiga_stew")));

    /** Тёплый камень: пока он в руке, метель не обмораживает (замедление остаётся). */
    public static final Item HEARTH_STONE = register("hearth_stone",
            Item::new,
            new Item.Properties().stacksTo(1)
                    .component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true)
                    .component(DataComponents.LORE, lore("hearth_stone")));

    /** Таёжный топор: как железный, но рубка даёт щепки, иней и звук (см. AxeEffects). */
    public static final Item TAIGA_AXE = register("taiga_axe", Item::new,
            new Item.Properties().axe(ToolMaterial.IRON, 6.0F, -3.1F)
                    .component(DataComponents.LORE, lore("taiga_axe")));

    // ---- Олень ----
    public static final Item DEER_HIDE = register("deer_hide", Item::new, new Item.Properties());

    public static final Item RAW_VENISON = register("raw_venison", Item::new,
            new Item.Properties().food(new FoodProperties.Builder().nutrition(3).saturationModifier(0.3f).build()));

    public static final Item COOKED_VENISON = register("cooked_venison", Item::new,
            new Item.Properties().food(new FoodProperties.Builder().nutrition(8).saturationModifier(0.8f).build()));

    // ---- Меховая броня из шкуры оленя (защита от метели, см. BlizzardEffects) ----
    public static final Item DEER_CAP = register("deer_cap", Item::new,
            new Item.Properties().humanoidArmor(ModArmorMaterials.DEER_HIDE, ArmorType.HELMET)
                    .component(DataComponents.LORE, lore("deer_armor")));
    public static final Item DEER_JACKET = register("deer_jacket", Item::new,
            new Item.Properties().humanoidArmor(ModArmorMaterials.DEER_HIDE, ArmorType.CHESTPLATE)
                    .component(DataComponents.LORE, lore("deer_armor")));
    public static final Item DEER_TROUSERS = register("deer_trousers", Item::new,
            new Item.Properties().humanoidArmor(ModArmorMaterials.DEER_HIDE, ArmorType.LEGGINGS)
                    .component(DataComponents.LORE, lore("deer_armor")));
    public static final Item DEER_BOOTS = register("deer_boots", Item::new,
            new Item.Properties().humanoidArmor(ModArmorMaterials.DEER_HIDE, ArmorType.BOOTS)
                    .component(DataComponents.LORE, lore("deer_armor")));

    private static ItemLore lore(String name) {
        return new ItemLore(List.of(Component.translatable("item." + TaigaNights.MOD_ID + "." + name + ".lore")));
    }

    private static <T extends Item> T register(String name, Function<Item.Properties, T> factory, Item.Properties props) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM,
                Identifier.fromNamespaceAndPath(TaigaNights.MOD_ID, name));
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.setId(key)));
    }

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.FOOD_AND_DRINKS).register(entries -> {
            entries.accept(SPRUCE_TEA);
            entries.accept(TAIGA_STEW);
            entries.accept(RAW_VENISON);
            entries.accept(COOKED_VENISON);
        });
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS).register(entries ->
                entries.accept(DEER_HIDE));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(entries -> {
            entries.accept(DEER_CAP);
            entries.accept(DEER_JACKET);
            entries.accept(DEER_TROUSERS);
            entries.accept(DEER_BOOTS);
        });
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> {
            entries.accept(HEARTH_STONE);
            entries.accept(TAIGA_AXE);
        });
    }

    private ModItems() {}
}
