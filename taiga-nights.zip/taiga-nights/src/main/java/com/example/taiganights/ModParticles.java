package com.example.taiganights;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.core.Registry;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;

public final class ModParticles {
    public static final SimpleParticleType SNOW_GUST = register("snow_gust");
    public static final SimpleParticleType FROST_MOTE = register("frost_mote");

    private static SimpleParticleType register(String name) {
        return Registry.register(BuiltInRegistries.PARTICLE_TYPE,
                Identifier.fromNamespaceAndPath(TaigaNights.MOD_ID, name),
                FabricParticleTypes.simple());
    }

    public static void init() {}

    private ModParticles() {}
}
