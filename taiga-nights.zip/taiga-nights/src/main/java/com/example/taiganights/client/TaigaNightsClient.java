package com.example.taiganights.client;

import com.example.taiganights.ModEntities;
import com.example.taiganights.ModParticles;
import com.example.taiganights.client.render.DeerModel;
import com.example.taiganights.client.render.DeerRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.particle.SnowflakeParticle;

public class TaigaNightsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Своё поведение частиц не пишем: берём ванильную «снежинку», но с нашими текстурами.
        ParticleFactoryRegistry.getInstance().register(ModParticles.SNOW_GUST, SnowflakeParticle.Provider::new);
        ParticleFactoryRegistry.getInstance().register(ModParticles.FROST_MOTE, SnowflakeParticle.Provider::new);

        EntityModelLayerRegistry.registerModelLayer(DeerModel.LAYER, DeerModel::createBodyLayer);
        EntityRendererRegistry.register(ModEntities.DEER, DeerRenderer::new);

        ClientTickEvents.END_CLIENT_TICK.register(AtmosphereClient::tick);
    }
}
