package com.example.taiganights.client.render;

import com.example.taiganights.TaigaNights;
import com.example.taiganights.entity.DeerEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;

public class DeerRenderer extends MobRenderer<DeerEntity, LivingEntityRenderState, DeerModel> {
    private static final Identifier TEXTURE =
            Identifier.fromNamespaceAndPath(TaigaNights.MOD_ID, "textures/entity/deer.png");

    public DeerRenderer(EntityRendererProvider.Context context) {
        super(context, new DeerModel(context.bakeLayer(DeerModel.LAYER)), 0.45F);
    }

    @Override
    public LivingEntityRenderState createRenderState() {
        return new LivingEntityRenderState();
    }

    @Override
    public Identifier getTextureLocation(LivingEntityRenderState state) {
        return TEXTURE;
    }
}
