package com.example.taiganights;

import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

public final class ModEffects {
    /** «Тепло»: полный иммунитет к метели (холод и замедление). */
    public static final Holder<MobEffect> WARMTH = register("warmth", new WarmthEffect());

    private static final class WarmthEffect extends MobEffect {
        WarmthEffect() {
            super(MobEffectCategory.BENEFICIAL, 0xFF9A3C);
        }
    }

    private static Holder<MobEffect> register(String name, MobEffect effect) {
        return Registry.registerForHolder(BuiltInRegistries.MOB_EFFECT,
                Identifier.fromNamespaceAndPath(TaigaNights.MOD_ID, name), effect);
    }

    public static void init() {}

    private ModEffects() {}
}
