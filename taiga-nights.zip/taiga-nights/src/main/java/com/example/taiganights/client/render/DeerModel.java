package com.example.taiganights.client.render;

import com.example.taiganights.TaigaNights;
import net.minecraft.client.model.QuadrupedModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.resources.Identifier;

/** Модель оленя. Ходьбу и поворот головы берём у QuadrupedModel (ваниль). */
public class DeerModel extends QuadrupedModel<LivingEntityRenderState> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(Identifier.fromNamespaceAndPath(TaigaNights.MOD_ID, "deer"), "main");

    public DeerModel(ModelPart root) {
        super(root);
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 16).addBox(-3.0F, -4.0F, -8.0F, 6.0F, 8.0F, 16.0F),
                PartPose.offset(0.0F, 9.0F, 1.0F));

        root.addOrReplaceChild("neck",
                CubeListBuilder.create().texOffs(36, 0).addBox(-2.0F, -6.0F, -2.0F, 4.0F, 7.0F, 4.0F),
                PartPose.offset(0.0F, 6.0F, -6.0F));

        root.addOrReplaceChild("head", CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-2.5F, -4.0F, -3.0F, 5.0F, 5.0F, 6.0F)      // череп
                        .texOffs(22, 0).addBox(-1.5F, -1.0F, -7.0F, 3.0F, 3.0F, 4.0F)     // морда
                        .texOffs(52, 0).addBox(-4.5F, -3.0F, 0.5F, 2.0F, 3.0F, 1.0F)      // ухо
                        .texOffs(52, 0).addBox(2.5F, -3.0F, 0.5F, 2.0F, 3.0F, 1.0F)       // ухо
                        .texOffs(52, 5).addBox(-2.5F, -11.0F, 0.0F, 1.0F, 7.0F, 1.0F)     // рог
                        .texOffs(52, 5).addBox(1.5F, -11.0F, 0.0F, 1.0F, 7.0F, 1.0F)      // рог
                        .texOffs(56, 5).addBox(-4.5F, -10.0F, 0.0F, 2.0F, 1.0F, 1.0F)     // отростки
                        .texOffs(56, 5).addBox(2.5F, -10.0F, 0.0F, 2.0F, 1.0F, 1.0F)
                        .texOffs(56, 5).addBox(-4.5F, -7.0F, 0.0F, 2.0F, 1.0F, 1.0F)
                        .texOffs(56, 5).addBox(2.5F, -7.0F, 0.0F, 2.0F, 1.0F, 1.0F),
                PartPose.offset(0.0F, 1.0F, -6.0F));

        CubeListBuilder leg = CubeListBuilder.create().texOffs(0, 40).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 11.0F, 2.0F);
        root.addOrReplaceChild("right_hind_leg", leg, PartPose.offset(-2.5F, 13.0F, 8.0F));
        root.addOrReplaceChild("left_hind_leg", leg, PartPose.offset(2.5F, 13.0F, 8.0F));
        root.addOrReplaceChild("right_front_leg", leg, PartPose.offset(-2.5F, 13.0F, -5.0F));
        root.addOrReplaceChild("left_front_leg", leg, PartPose.offset(2.5F, 13.0F, -5.0F));

        return LayerDefinition.create(mesh, 64, 64);
    }
}
