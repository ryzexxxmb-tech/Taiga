package com.example.taiganights;

import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

public final class ModArmorMaterials {
    public static final ResourceKey<EquipmentAsset> DEER_HIDE_ASSET = ResourceKey.create(
            EquipmentAssets.ROOT_ID, Identifier.fromNamespaceAndPath(TaigaNights.MOD_ID, "deer_hide"));

    /** Чем чинится броня (тег data/taiga_nights/tags/item/repairs_deer_hide.json). */
    public static final TagKey<Item> REPAIRS_DEER_HIDE = TagKey.create(Registries.ITEM,
            Identifier.fromNamespaceAndPath(TaigaNights.MOD_ID, "repairs_deer_hide"));

    public static final ArmorMaterial DEER_HIDE = new ArmorMaterial(
            8,
            Map.of(ArmorType.BOOTS, 1, ArmorType.LEGGINGS, 2, ArmorType.CHESTPLATE, 3,
                    ArmorType.HELMET, 1, ArmorType.BODY, 3),
            12,
            SoundEvents.ARMOR_EQUIP_LEATHER,
            0.0F, 0.0F,
            REPAIRS_DEER_HIDE,
            DEER_HIDE_ASSET);

    private ModArmorMaterials() {}
}
