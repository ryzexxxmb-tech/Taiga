package com.example.taiganights.client;

import com.example.taiganights.ModItems;
import com.example.taiganights.ModParticles;
import com.example.taiganights.ModSounds;
import com.example.taiganights.TaigaWeather;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BiomeTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Клиентская атмосфера: частицы и звуки метели и ночной тайги. */
public final class AtmosphereClient {
    private static int windCooldown = 0;
    private static int nightCooldown = 200;

    public static void tick(Minecraft mc) {
        ClientLevel level = mc.level;
        LocalPlayer player = mc.player;
        if (level == null || player == null || mc.isPaused()) return;
        heldAxeAura(level, player);
        if (!level.dimension().equals(Level.OVERWORLD)) return;
        if (!level.getBiome(player.blockPosition()).is(BiomeTags.IS_TAIGA)) return;

        RandomSource random = level.getRandom();
        float blizzard = TaigaWeather.blizzardIntensity(level);

        if (blizzard > 0f) {
            blizzard(level, player, random, blizzard);
        } else {
            windCooldown = 0;
        }
        if (level.isDarkOutside()) {
            night(level, player, random, blizzard);
        }
    }

    /** Морозные искорки вокруг Таёжного топора в руке (работает в любом биоме). */
    private static void heldAxeAura(ClientLevel level, LocalPlayer player) {
        if (!player.getMainHandItem().is(ModItems.TAIGA_AXE)) return;
        RandomSource random = level.getRandom();
        if (random.nextInt(5) != 0) return;
        Vec3 look = player.getLookAngle();
        Vec3 right = new Vec3(-look.z, 0, look.x).normalize();
        Vec3 p = player.getEyePosition().add(look.scale(0.6)).add(right.scale(0.35)).add(0, -0.45, 0);
        level.addParticle(ModParticles.FROST_MOTE,
                p.x + (random.nextDouble() - 0.5) * 0.3, p.y + (random.nextDouble() - 0.5) * 0.4, p.z + (random.nextDouble() - 0.5) * 0.3,
                0.0, 0.012, 0.0);
    }

    private static void blizzard(ClientLevel level, LocalPlayer player, RandomSource random, float intensity) {
        double angle = TaigaWeather.windAngle(level);
        double vx = Math.cos(angle) * 0.7;
        double vz = Math.sin(angle) * 0.7;

        int count = Math.round(18 * intensity);
        for (int i = 0; i < count; i++) {
            double x = player.getX() + (random.nextDouble() - 0.5) * 36;
            double y = player.getY() + random.nextDouble() * 12 - 2;
            double z = player.getZ() + (random.nextDouble() - 0.5) * 36;
            if (!level.canSeeSky(BlockPos.containing(x, y, z))) continue; // под кроной снег не летит
            level.addParticle(ModParticles.SNOW_GUST, x, y, z, vx, -0.03, vz);
        }

        if (windCooldown-- <= 0) {
            boolean open = level.canSeeSky(player.blockPosition());
            float volume = (open ? 1.0f : 0.45f) * (0.35f + 0.65f * intensity);
            level.playLocalSound(player.getX(), player.getY(), player.getZ(),
                    ModSounds.BLIZZARD_WIND, SoundSource.WEATHER,
                    volume, 0.9f + random.nextFloat() * 0.2f, false);
            windCooldown = 150 + random.nextInt(40);
        }
    }

    private static void night(ClientLevel level, LocalPlayer player, RandomSource random, float blizzard) {
        // Морозные искорки в воздухе
        if (blizzard < 0.5f && random.nextInt(3) == 0) {
            double x = player.getX() + (random.nextDouble() - 0.5) * 24;
            double y = player.getY() + random.nextDouble() * 5 - 1;
            double z = player.getZ() + (random.nextDouble() - 0.5) * 24;
            level.addParticle(ModParticles.FROST_MOTE, x, y, z,
                    (random.nextDouble() - 0.5) * 0.02, 0.02 + random.nextDouble() * 0.02, (random.nextDouble() - 0.5) * 0.02);
        }

        // Далёкий вой и уханье совы из темноты
        if (nightCooldown-- <= 0) {
            nightCooldown = 600 + random.nextInt(1200); // 30-90 секунд
            if (blizzard > 0.5f) return; // в метель ветер заглушает всё
            double angle = random.nextDouble() * Math.PI * 2;
            double dist = 24 + random.nextDouble() * 24;
            boolean howl = random.nextFloat() < 0.35f;
            level.playLocalSound(
                    player.getX() + Math.cos(angle) * dist, player.getY(), player.getZ() + Math.sin(angle) * dist,
                    howl ? ModSounds.NIGHT_HOWL : ModSounds.NIGHT_OWL, SoundSource.AMBIENT,
                    howl ? 2.0f : 1.2f, 0.9f + random.nextFloat() * 0.2f, false);
        }
    }

    private AtmosphereClient() {}
}
