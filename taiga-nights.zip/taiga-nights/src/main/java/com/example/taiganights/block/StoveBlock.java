package com.example.taiganights.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Каменка. Топливо хранится в состоянии блока (fuel 0-8), одна единица горит 1 минуту.
 * Топят углём, древесным углём (+2) и брёвнами (+1). Греет игроков в радиусе 10 блоков (см. BlizzardEffects).
 */
public class StoveBlock extends HorizontalDirectionalBlock {
    public static final MapCodec<StoveBlock> CODEC = simpleCodec(StoveBlock::new);
    public static final IntegerProperty FUEL = IntegerProperty.create("fuel", 0, 8);
    public static final int MAX_FUEL = 8;
    public static final int BURN_UNIT_TICKS = 1200;

    public StoveBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(FUEL, 0));
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, FUEL);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    private static int fuelUnits(ItemStack stack) {
        if (stack.is(ItemTags.COALS)) return 2;
        if (stack.is(ItemTags.LOGS_THAT_BURN)) return 1;
        return 0;
    }

    @Override
    protected InteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                          Player player, InteractionHand hand, BlockHitResult hit) {
        int add = fuelUnits(stack);
        int fuel = state.getValue(FUEL);
        if (add == 0 || fuel >= MAX_FUEL) return InteractionResult.TRY_WITH_EMPTY_HAND;

        if (level instanceof ServerLevel serverLevel) {
            serverLevel.setBlock(pos, state.setValue(FUEL, Math.min(MAX_FUEL, fuel + add)), Block.UPDATE_ALL);
            if (fuel == 0) serverLevel.scheduleTick(pos, this, BURN_UNIT_TICKS);
            if (!player.isCreative()) stack.shrink(1);
            serverLevel.playSound(null, pos, SoundEvents.FIRECHARGE_USE, SoundSource.BLOCKS, 0.8F, 1.0F);
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player,
                                               BlockHitResult hit) {
        player.displayClientMessage(
                Component.translatable("message.taiga_nights.stove_fuel", state.getValue(FUEL)), true);
        return InteractionResult.SUCCESS;
    }

    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        int fuel = state.getValue(FUEL);
        if (fuel <= 0) return;
        level.setBlock(pos, state.setValue(FUEL, fuel - 1), Block.UPDATE_ALL);
        if (fuel - 1 > 0) level.scheduleTick(pos, this, BURN_UNIT_TICKS);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (state.getValue(FUEL) <= 0) return;
        if (random.nextInt(4) == 0) {
            level.addParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE,
                    pos.getX() + 0.5, pos.getY() + 1.05, pos.getZ() + 0.5, 0.0, 0.07, 0.0);
        }
        if (random.nextInt(40) == 0) {
            level.playLocalSound(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    SoundEvents.CAMPFIRE_CRACKLE, SoundSource.BLOCKS, 0.6F, 1.0F, false);
        }
    }
}
