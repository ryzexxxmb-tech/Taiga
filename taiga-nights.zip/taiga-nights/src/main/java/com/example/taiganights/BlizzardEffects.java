package com.example.taiganights;

import com.example.taiganights.block.StoveBlock;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Эффекты метели на сервере (игрок под открытым небом в тайге).
 *
 * Защита:
 *  - укрытие: крона елей / крыша над головой (метель не действует);
 *  - тепло рядом: каменка (радиус 10) или горящий костёр (радиус 5);
 *  - эффект «Тепло» (чай, похлёбка);
 *  - меховая броня: 1 деталь замедляет обморожение, 2+ полностью защищают от обморожения, 3+ убирают и замедление;
 *  - Тёплый камень в руке защищает от обморожения.
 */
public final class BlizzardEffects {
    private static final Map<UUID, Boolean> NEAR_HEAT = new HashMap<>();

    public static void tick(MinecraftServer server) {
        int tick = server.getTickCount();
        if (tick % 4 != 0) return;

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (player.isSpectator() || player.isCreative()) continue;
            if (!(player.level() instanceof ServerLevel level)) continue;

            float intensity = TaigaWeather.blizzardIntensity(level);
            if (intensity < 0.3f) continue;
            if (player.hasEffect(ModEffects.WARMTH)) continue;

            BlockPos pos = player.blockPosition();
            if (!level.getBiome(pos).is(BiomeTags.IS_TAIGA)) continue;
            if (!level.canSeeSky(pos)) continue;

            // Поиск источника тепла раз в секунду (дорогая проверка), результат кэшируем.
            if (tick % 20 == 0) NEAR_HEAT.put(player.getUUID(), nearHeat(level, pos));
            if (NEAR_HEAT.getOrDefault(player.getUUID(), false)) {
                player.addEffect(new MobEffectInstance(ModEffects.WARMTH, 60, 0, true, false, true));
                continue;
            }

            int hide = hideArmorPieces(player);
            boolean hearth = player.getMainHandItem().is(ModItems.HEARTH_STONE)
                    || player.getOffhandItem().is(ModItems.HEARTH_STONE);

            if (hide < 2 && !hearth) {
                int add = hide == 0 ? 10 : 9; // чуть быстрее естественного оттаивания (8 за 4 тика)
                player.setTicksFrozen(Math.min(player.getTicksFrozen() + add, player.getTicksRequiredToFreeze()));
                // Ваниль не бьёт холодом тех, кто в коже; в метель бьём всех одинаково.
                if (tick % 40 == 0 && player.isFullyFrozen() && !player.canFreeze()) {
                    player.hurtServer(level, level.damageSources().freeze(), 1.0f);
                }
            }

            if (hide < 3 && tick % 20 == 0 && intensity > 0.5f) {
                player.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 0, true, false));
            }
        }
    }

    private static int hideArmorPieces(ServerPlayer p) {
        int n = 0;
        if (p.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.DEER_CAP)) n++;
        if (p.getItemBySlot(EquipmentSlot.CHEST).is(ModItems.DEER_JACKET)) n++;
        if (p.getItemBySlot(EquipmentSlot.LEGS).is(ModItems.DEER_TROUSERS)) n++;
        if (p.getItemBySlot(EquipmentSlot.FEET).is(ModItems.DEER_BOOTS)) n++;
        return n;
    }

    /** Каменка с топливом в радиусе 10 блоков или костёр/огонь в радиусе 5. */
    private static boolean nearHeat(Level level, BlockPos c) {
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-10, -4, -10), c.offset(10, 4, 10))) {
            int dx = p.getX() - c.getX();
            int dy = p.getY() - c.getY();
            int dz = p.getZ() - c.getZ();
            int d2 = dx * dx + dy * dy + dz * dz;
            if (d2 > 100) continue;
            BlockState s = level.getBlockState(p);
            if (s.is(ModBlocks.STOVE) && s.getValue(StoveBlock.FUEL) > 0) return true;
            if (d2 <= 25 && (CampfireBlock.isLitCampfire(s) || s.is(Blocks.FIRE) || s.is(Blocks.SOUL_FIRE))) return true;
        }
        return false;
    }

    private BlizzardEffects() {}
}
