package com.example.taiganights;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionResult;

/** Эффекты рубки Таёжным топором: щепки, иней и звук. Частицы шлёт сервер, их видят все рядом. */
public final class AxeEffects {

    public static void init() {
        // Срубил бревно: щепки блока + иней + звук
        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, blockEntity) -> {
            if (!(level instanceof ServerLevel sl)) return;
            if (!player.getMainHandItem().is(ModItems.TAIGA_AXE)) return;
            if (!state.is(BlockTags.LOGS)) return;

            double x = pos.getX() + 0.5, y = pos.getY() + 0.5, z = pos.getZ() + 0.5;
            sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state), x, y, z, 24, 0.35, 0.35, 0.35, 0.12);
            sl.sendParticles(ModParticles.SNOW_GUST, x, y + 0.4, z, 10, 0.4, 0.3, 0.4, 0.06);
            sl.sendParticles(ModParticles.FROST_MOTE, x, y + 0.2, z, 6, 0.5, 0.4, 0.5, 0.02);
            sl.playSound(null, pos, ModSounds.AXE_CHOP, SoundSource.BLOCKS, 0.9f, 0.95f + sl.getRandom().nextFloat() * 0.15f);
        });

        // Удар по существу: ледяная вспышка в точке попадания
        AttackEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
            if (level instanceof ServerLevel sl && !player.isSpectator()
                    && player.getMainHandItem().is(ModItems.TAIGA_AXE)) {
                double x = entity.getX(), y = entity.getY() + entity.getBbHeight() * 0.6, z = entity.getZ();
                sl.sendParticles(ModParticles.SNOW_GUST, x, y, z, 14, 0.25, 0.3, 0.25, 0.15);
                sl.sendParticles(ModParticles.FROST_MOTE, x, y, z, 6, 0.3, 0.3, 0.3, 0.03);
                sl.playSound(null, entity.blockPosition(), ModSounds.AXE_CHOP, SoundSource.PLAYERS, 0.8f,
                        1.1f + sl.getRandom().nextFloat() * 0.2f);
            }
            return InteractionResult.PASS;
        });
    }

    private AxeEffects() {}
}
