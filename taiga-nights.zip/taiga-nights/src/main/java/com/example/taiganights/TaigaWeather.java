package com.example.taiganights;

import net.minecraft.world.level.Level;

/**
 * Метель вычисляется детерминированно из игрового времени, поэтому клиент и сервер
 * согласуются без пакетов. Время режется на окна; в части окон идёт метель.
 */
public final class TaigaWeather {
    /** Длина окна в тиках (9000 = 7,5 минуты). */
    public static final long WINDOW_TICKS = 9000L;
    /** Шанс метели в окне, %. Для теста поставь 100. */
    public static final int BLIZZARD_CHANCE_PERCENT = 25;

    /** 0 = метели нет, 1 = полная сила. Плавно нарастает и затихает по краям окна. */
    public static float blizzardIntensity(Level level) {
        if (!level.dimension().equals(Level.OVERWORLD)) return 0f;
        long time = level.getGameTime();
        long window = time / WINDOW_TICKS;
        if (Long.remainderUnsigned(mix(window), 100) >= BLIZZARD_CHANCE_PERCENT) return 0f;
        float t = (time % WINDOW_TICKS) / (float) WINDOW_TICKS;
        return Math.min(1f, Math.min(t, 1f - t) / 0.12f);
    }

    /** Направление ветра (радианы), постоянное в пределах окна. */
    public static double windAngle(Level level) {
        long window = level.getGameTime() / WINDOW_TICKS;
        long h = Long.remainderUnsigned(mix(window ^ 0x5DEECE66DL), 36000);
        return h / 36000.0 * Math.PI * 2.0;
    }

    private static long mix(long x) {
        long z = x + 0x9E3779B97F4A7C15L;
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }

    private TaigaWeather() {}
}
