package com.example.taiganights;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Еда/питьё, которое отогревает: снимает обморожение и даёт эффект «Тепло». */
public class WarmingItem extends Item {
    private final int warmthTicks;

    public WarmingItem(Properties properties, int warmthTicks) {
        super(properties);
        this.warmthTicks = warmthTicks;
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        ItemStack result = super.finishUsingItem(stack, level, entity);
        if (level instanceof ServerLevel) {
            entity.setTicksFrozen(0);
            entity.addEffect(new MobEffectInstance(ModEffects.WARMTH, warmthTicks, 0));
        }
        return result;
    }
}
