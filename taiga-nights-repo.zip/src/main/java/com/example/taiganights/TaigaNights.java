package com.example.taiganights;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

public class TaigaNights implements ModInitializer {
    public static final String MOD_ID = "taiga_nights";

    @Override
    public void onInitialize() {
        ModSounds.init();
        ModEffects.init();
        ModItems.init();
        ModBlocks.init();
        ModEntities.init();
        AxeEffects.init();
        TreeFelling.init();
        ModParticles.init();
        ServerTickEvents.END_SERVER_TICK.register(BlizzardEffects::tick);
    }
}
