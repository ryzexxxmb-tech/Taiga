package com.example.taiganights;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Рубка деревьев как в The Forest.
 *
 * 1. Удар топором по бревну естественного дерева не ломает блок, а делает надруб: щепки, звук, трещина на стволе.
 *    Удары копятся (чем больше дерево, тем их больше нужно). Ближе к концу дерево трещит и роняет листья.
 * 2. Последний удар: дерево целиком (ствол, ветки, крона) отрывается от пенька и падает ОТ игрока
 *    по физике маятника (медленно кренится, потом всё быстрее), давит всех на пути, цепляется за склон
 *    или другое препятствие, с грохотом ложится и рассыпается на брёвна.
 *
 * Падающее дерево рисуется ванильными block_display (клиентского кода и ресурсов не нужно):
 * все куски делят одну точку вращения (пенёк), сервер крутит только наклон (pitch) сущностей.
 */
public final class TreeFelling {

    // ---- Настройки ----
    /** Минимум тиков между ударами (≈ замах топора). */
    private static final int SWING_COOLDOWN = 14;
    /** Дерево с большим числом брёвен считаем не деревом (вдруг это постройка). */
    private static final int MAX_LOGS = 160;
    /** Не шире этого в блоках по осям X/Z (иначе это не одно дерево). */
    private static final int MAX_SPREAD = 11;
    /** Макс. число листьев, которые летят вместе с деревом (остальные просто осыпаются). */
    private static final int MAX_LEAF_PIECES = 140;
    /** Как далеко от брёвен листва считается частью этого дерева. */
    private static final int LEAF_RANGE = 5;
    /** Сколько ударов нужно: BASE + брёвна / DIV (в пределах MIN..MAX) при силе железного топора. */
    private static final float HITS_BASE = 3.0f, HITS_DIV = 2.2f, HITS_MIN = 5.0f, HITS_MAX = 20.0f;
    /** Ускорение падения (1.0 = «как в жизни», больше = быстрее). */
    private static final double GRAVITY_SCALE = 1.3;
    /** Урон от падающего ствола: BASE + угловая скорость * PER_SPEED. */
    private static final float CRUSH_BASE = 4.0f, CRUSH_PER_SPEED = 4.0f;
    /** Через сколько тиков без ударов дерево «залечивает» надруб. */
    private static final int HEAL_AFTER_TICKS = 300;
    /** Если дерево падает не в ту сторону (наклон в противоположную), поставь -1. */
    private static final float PITCH_SIGN = 1.0f;

    private static final String FALL_TAG = "taiga_nights_fall";
    private static final double DT = 0.05;

    private static final Map<GlobalPos, Progress> PROGRESS = new HashMap<>();
    private static final Map<UUID, Long> NEXT_HIT_SERVER = new HashMap<>();
    private static final List<Fall> FALLS = new ArrayList<>();
    private static long nextHitClient = 0;

    public static void init() {
        AttackBlockCallback.EVENT.register(TreeFelling::onAttack);
        ServerTickEvents.END_SERVER_TICK.register(TreeFelling::tick);
        // Останавливаем сервер посреди падения: дерево сразу ложится и рассыпается, ничего не теряется.
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            for (Fall f : FALLS) f.finishNow();
            FALLS.clear();
        });
    }

    // =====================================================================================
    //  Удар по бревну
    // =====================================================================================

    private static InteractionResult onAttack(Player player, Level level, InteractionHand hand, BlockPos pos, Direction face) {
        if (hand != InteractionHand.MAIN_HAND || player.isSpectator() || !player.mayBuild()) return InteractionResult.PASS;
        ItemStack tool = player.getMainHandItem();
        if (!tool.is(ItemTags.AXES)) return InteractionResult.PASS;
        BlockState state = level.getBlockState(pos);
        if (!state.is(BlockTags.LOGS)) return InteractionResult.PASS;

        Tree tree = scan(level, pos);
        if (tree == null) return InteractionResult.PASS; // не естественное дерево: обычная ломка блока

        long now = level.getGameTime();
        if (!(level instanceof ServerLevel sl)) {
            // Клиент: тот же замах, чтобы рука не махала каждый тик. SUCCESS отправит удар на сервер.
            if (now < nextHitClient) return InteractionResult.FAIL;
            nextHitClient = now + SWING_COOLDOWN;
            return InteractionResult.SUCCESS;
        }

        Long next = NEXT_HIT_SERVER.get(player.getUUID());
        if (next != null && now < next - 3) return InteractionResult.FAIL; // небольшой запас на лаг
        NEXT_HIT_SERVER.put(player.getUUID(), now + SWING_COOLDOWN);

        hit(sl, player, pos, face, state, tool, tree);
        return InteractionResult.SUCCESS;
    }

    private static void hit(ServerLevel sl, Player player, BlockPos pos, Direction face, BlockState state,
                            ItemStack tool, Tree tree) {
        GlobalPos key = GlobalPos.of(sl.dimension(), tree.stump);
        Progress pr = PROGRESS.computeIfAbsent(key, k -> new Progress(crackId(tree.stump)));
        pr.lastTick = sl.getGameTime();
        pr.lastHit = pos;

        float power = Math.max(0.5f, Math.min(2.0f, tool.getDestroySpeed(state) / 6.0f));
        pr.hits += power;
        float need = hitsNeeded(tree);
        float ratio = Math.min(1.0f, pr.hits / need);

        // Трещина на стволе в месте удара
        sl.destroyBlockProgress(pr.crackId, pos, Math.min(9, (int) (ratio * 10)));

        // Щепки, звук
        double hx = pos.getX() + 0.5 + face.getStepX() * 0.55;
        double hy = pos.getY() + 0.5 + face.getStepY() * 0.55;
        double hz = pos.getZ() + 0.5 + face.getStepZ() * 0.55;
        sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state), hx, hy, hz, 12, 0.18, 0.18, 0.18, 0.08);
        float pitch = 0.9f + sl.getRandom().nextFloat() * 0.2f;
        sl.playSound(null, pos, ModSounds.AXE_CHOP, SoundSource.BLOCKS, 1.0f, pitch);
        sl.playSound(null, pos, state.getSoundType().getHitSound(), SoundSource.BLOCKS, 0.9f, 0.7f);
        if (tool.is(ModItems.TAIGA_AXE)) {
            sl.sendParticles(ModParticles.SNOW_GUST, hx, hy, hz, 5, 0.2, 0.2, 0.2, 0.08);
            sl.sendParticles(ModParticles.FROST_MOTE, hx, hy, hz, 3, 0.25, 0.25, 0.25, 0.02);
        }

        // Дерево «чувствует» удары: с половины надруба шумит и роняет листья, перед падением трещит
        if (ratio >= 0.5f && !tree.leaves.isEmpty()) {
            BlockPos lp = tree.leaves.get(sl.getRandom().nextInt(tree.leaves.size()));
            BlockState ls = sl.getBlockState(lp);
            sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, ls), lp.getX() + 0.5, lp.getY() + 0.2,
                    lp.getZ() + 0.5, 6, 0.5, 0.2, 0.5, 0.02);
            sl.playSound(null, lp, ls.getSoundType().getBreakSound(), SoundSource.BLOCKS, 0.6f, 0.8f);
        }
        if (ratio >= 0.75f) {
            sl.playSound(null, tree.stump, state.getSoundType().getBreakSound(), SoundSource.BLOCKS, 1.3f,
                    0.45f + sl.getRandom().nextFloat() * 0.1f);
        }

        // Износ топора и усталость
        if (!player.isCreative()) tool.hurtAndBreak(1, player, EquipmentSlot.MAINHAND);
        player.causeFoodExhaustion(0.04f);

        if (pr.hits >= need) {
            PROGRESS.remove(key);
            sl.destroyBlockProgress(pr.crackId, pos, -1);
            startFall(sl, player, tree, tool);
        }
    }

    private static float hitsNeeded(Tree tree) {
        float total = tree.logs.size() + 1;
        return Math.max(HITS_MIN, Math.min(HITS_MAX, HITS_BASE + total / HITS_DIV));
    }

    private static int crackId(BlockPos stump) {
        // Отрицательные id не пересекаются с id сущностей игроков
        return -1 - (stump.hashCode() & 0x3fffffff);
    }

    // =====================================================================================
    //  Поиск дерева (работает и на клиенте, и на сервере)
    // =====================================================================================

    private record Tree(BlockPos stump, List<BlockPos> logs, List<BlockPos> leaves) {}

    /** Находит естественное дерево, которому принадлежит бревно {@code hit}; null, если это не дерево. */
    private static Tree scan(Level level, BlockPos hit) {
        Set<BlockPos> logs = new HashSet<>();
        ArrayDeque<BlockPos> queue = new ArrayDeque<>();
        logs.add(hit);
        queue.add(hit);
        int minX = hit.getX(), maxX = hit.getX(), minZ = hit.getZ(), maxZ = hit.getZ();

        while (!queue.isEmpty()) {
            BlockPos p = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        // вниз по диагонали не ходим: так не зацепимся за постройки рядом
                        if (dy < 0 && (dx != 0 || dz != 0)) continue;
                        BlockPos n = p.offset(dx, dy, dz);
                        if (logs.contains(n) || !level.getBlockState(n).is(BlockTags.LOGS)) continue;
                        logs.add(n);
                        if (logs.size() > MAX_LOGS) return null;
                        minX = Math.min(minX, n.getX());
                        maxX = Math.max(maxX, n.getX());
                        minZ = Math.min(minZ, n.getZ());
                        maxZ = Math.max(maxZ, n.getZ());
                        if (maxX - minX > MAX_SPREAD || maxZ - minZ > MAX_SPREAD) return null;
                        queue.add(n);
                    }
                }
            }
        }

        // Пенёк: самое нижнее бревно, из них ближайшее к месту удара
        BlockPos stump = null;
        int bestY = Integer.MAX_VALUE;
        double bestD = Double.MAX_VALUE;
        for (BlockPos p : logs) {
            double d = (p.getX() - hit.getX()) * (double) (p.getX() - hit.getX())
                    + (p.getZ() - hit.getZ()) * (double) (p.getZ() - hit.getZ());
            if (p.getY() < bestY || (p.getY() == bestY && d < bestD)) {
                bestY = p.getY();
                bestD = d;
                stump = p;
            }
        }
        if (stump == null) return null;
        // Растёт из земли (а не стоит на камне/досках)
        if (!level.getBlockState(stump.below()).is(BlockTags.DIRT)) return null;

        // Листва, выросшая вместе с деревом (не поставленная игроком)
        List<BlockPos> leaves = new ArrayList<>();
        Map<BlockPos, Integer> dist = new HashMap<>();
        ArrayDeque<BlockPos> lq = new ArrayDeque<>();
        for (BlockPos p : logs) {
            dist.put(p, 0);
            lq.add(p);
        }
        while (!lq.isEmpty()) {
            BlockPos p = lq.poll();
            int d = dist.get(p);
            if (d >= LEAF_RANGE) continue;
            for (Direction dir : Direction.values()) {
                BlockPos n = p.relative(dir);
                if (dist.containsKey(n)) continue;
                BlockState s = level.getBlockState(n);
                if (!(s.getBlock() instanceof LeavesBlock) || s.getValue(LeavesBlock.PERSISTENT)) continue;
                dist.put(n, d + 1);
                leaves.add(n);
                lq.add(n);
                if (leaves.size() > 600) break;
            }
        }
        if (leaves.isEmpty()) return null;

        logs.remove(stump);
        return new Tree(stump, new ArrayList<>(logs), leaves);
    }

    // =====================================================================================
    //  Падение
    // =====================================================================================

    private record Piece(UUID id, BlockState state, double rx, double ry, double rz, boolean log) {}

    private static void startFall(ServerLevel sl, Player player, Tree tree, ItemStack tool) {
        BlockPos stump = tree.stump;

        // Куда падать: ближайшая сторона света ОТ игрока (сетка блоков не позволяет косые углы без искажений)
        double ddx = stump.getX() + 0.5 - player.getX();
        double ddz = stump.getZ() + 0.5 - player.getZ();
        int fx = 0, fz = 0;
        if (Math.abs(ddx) < 1.0E-3 && Math.abs(ddz) < 1.0E-3) {
            Direction look = player.getDirection();
            fx = look.getStepX();
            fz = look.getStepZ();
        } else if (Math.abs(ddx) > Math.abs(ddz)) {
            fx = ddx > 0 ? 1 : -1;
        } else {
            fz = ddz > 0 ? 1 : -1;
        }

        Fall fall = new Fall(sl, stump, fx, fz);
        for (BlockPos p : tree.logs) fall.add(sl.getBlockState(p), p, true);
        int leafStep = Math.max(1, (int) Math.ceil(tree.leaves.size() / (double) MAX_LEAF_PIECES));
        for (int i = 0; i < tree.leaves.size(); i++) {
            BlockPos p = tree.leaves.get(i);
            BlockState s = sl.getBlockState(p);
            if (i % leafStep == 0) fall.add(s, p, false);
            else sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, s), p.getX() + 0.5, p.getY() + 0.5,
                    p.getZ() + 0.5, 3, 0.3, 0.3, 0.3, 0.05);
        }

        fall.spawnDisplays();
        // Только теперь убираем настоящие блоки (чтобы не мигало). Пенёк остаётся.
        for (BlockPos p : tree.logs) sl.setBlock(p, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);
        for (BlockPos p : tree.leaves) sl.setBlock(p, Blocks.AIR.defaultBlockState(), Block.UPDATE_ALL);

        if (tool.is(ModItems.TAIGA_AXE)) {
            sl.sendParticles(ModParticles.SNOW_GUST, stump.getX() + 0.5, stump.getY() + 1.0, stump.getZ() + 0.5,
                    24, 0.6, 0.5, 0.6, 0.1);
        }
        FALLS.add(fall);
        fall.begin();
    }

    private static final class Fall {
        private final ServerLevel level;
        private final BlockPos stump;
        private final int fx, fz;
        private final double px, py, pz; // точка вращения: центр пенька
        private final List<Piece> pieces = new ArrayList<>();
        private final Set<UUID> crushed = new HashSet<>();
        private double length = 3.0;      // высота дерева от точки вращения
        private double theta = 0.06;      // угол от вертикали, рад
        private double omega = 0.25;      // угловая скорость, рад/с
        private int age = 0;
        private SoundType crownSound = SoundType.GRASS;
        private boolean displaysOk = false;

        Fall(ServerLevel level, BlockPos stump, int fx, int fz) {
            this.level = level;
            this.stump = stump;
            this.fx = fx;
            this.fz = fz;
            this.px = stump.getX() + 0.5;
            this.py = stump.getY() + 0.5;
            this.pz = stump.getZ() + 0.5;
        }

        void add(BlockState state, BlockPos p, boolean log) {
            double rx = p.getX() + 0.5 - px, ry = p.getY() + 0.5 - py, rz = p.getZ() + 0.5 - pz;
            pieces.add(new Piece(UUID.randomUUID(), state, rx, ry, rz, log));
            length = Math.max(length, Math.sqrt(rx * rx + ry * ry + rz * rz));
            if (!log) crownSound = state.getSoundType();
        }

        /** Создаёт block_display на каждый кусок: одна точка вращения, смещение куска задано трансформацией. */
        void spawnDisplays() {
            MinecraftServer server = level.getServer();
            CommandSourceStack src = server.createCommandSourceStack().withLevel(level).withSuppressedOutput();
            float yaw = (float) Math.toDegrees(Math.atan2(-fx, fz));
            double box = 2.0 * (length + 3.0);
            for (Piece pc : pieces) {
                // координаты куска в системе сущности (она повёрнута по yaw в сторону падения)
                double lx = pc.rx * fz - pc.rz * fx;
                double ly = pc.ry;
                double lz = pc.rx * fx + pc.rz * fz;
                UUID u = pc.id;
                long m = u.getMostSignificantBits(), l = u.getLeastSignificantBits();
                String blockId = BuiltInRegistries.BLOCK.getKey(pc.state.getBlock()).toString();
                String props = pc.log ? ",Properties:{axis:\"y\"}" : "";
                String cmd = String.format(Locale.ROOT,
                        "summon minecraft:block_display %.3f %.3f %.3f {UUID:[I;%d,%d,%d,%d],Rotation:[%.1ff,0.0f],"
                                + "Tags:[\"%s\"],block_state:{Name:\"%s\"%s},teleport_duration:2,width:%.1ff,height:%.1ff,"
                                + "view_range:2.0f,transformation:{left_rotation:[0.0f,0.0f,0.0f,1.0f],"
                                + "right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[1.0f,1.0f,1.0f],"
                                + "translation:[%.4ff,%.4ff,%.4ff]}}",
                        px, py, pz, (int) (m >> 32), (int) m, (int) (l >> 32), (int) l, yaw,
                        FALL_TAG, blockId, props, box, length + 3.0, lx - 0.5, ly - 0.5, lz - 0.5);
                server.getCommands().performPrefixedCommand(src, cmd);
                if (level.getEntity(pc.id) != null) displaysOk = true;
            }
        }

        void begin() {
            level.playSound(null, stump, level.getBlockState(stump).getSoundType().getBreakSound(), SoundSource.BLOCKS,
                    2.0f, 0.5f);
            level.playSound(null, stump, ModSounds.AXE_CHOP, SoundSource.BLOCKS, 1.4f, 0.6f);
            if (!displaysOk) { // на всякий случай: без отрисовки просто валим мгновенно
                theta = Math.PI / 2;
                land();
            }
        }

        /** @return true, когда дерево упало и убрано */
        boolean tick() {
            if (!displaysOk) return true;
            age++;

            double alpha = 1.5 * 9.8 * GRAVITY_SCALE / length * Math.sin(theta);
            double nOmega = omega + alpha * DT;
            double nTheta = theta + nOmega * DT;
            boolean landed = false;
            if (nTheta >= Math.PI / 2) {
                nTheta = Math.PI / 2;
                landed = true;
            }
            if (blocked(nTheta)) { // уткнулось в склон / другое дерево: остаётся лежать наклонно
                nTheta = theta;
                landed = true;
            }
            omega = nOmega;
            theta = nTheta;

            crush();
            applyPitch();
            ambience();

            if (landed) {
                land();
                return true;
            }
            return false;
        }

        private void applyPitch() {
            float pitch = (float) Math.toDegrees(theta) * PITCH_SIGN;
            for (Piece pc : pieces) {
                Entity e = level.getEntity(pc.id);
                if (e != null) e.setXRot(pitch);
            }
        }

        /** Центр куска при текущем угле: поворот вокруг горизонтальной оси (Родриг), ось = Y x направление падения. */
        private double[] pos(Piece pc, double th) {
            double ax = fz, az = -fx; // ось вращения
            double c = Math.cos(th), s = Math.sin(th);
            double vx = pc.rx, vy = pc.ry, vz = pc.rz;
            double cx = -az * vy, cy = az * vx - ax * vz, cz = ax * vy; // a x v
            double dot = ax * vx + az * vz;
            return new double[]{
                    px + vx * c + cx * s + ax * dot * (1 - c),
                    py + vy * c + cy * s,
                    pz + vz * c + cz * s + az * dot * (1 - c)};
        }

        private boolean blocked(double th) {
            for (Piece pc : pieces) {
                if (!pc.log) continue; // листва проламывается
                double[] c = pos(pc, th);
                BlockPos bp = BlockPos.containing(c[0], c[1], c[2]);
                if (bp.getY() < stump.getY()) continue; // ниже пенька: земля, не считаем (стволы 2x2 «врезаются»)
                BlockState s = level.getBlockState(bp);
                if (s.is(BlockTags.LEAVES) || s.getCollisionShape(level, bp).isEmpty()) continue;
                return true;
            }
            return false;
        }

        /** Ствол бьёт всех, кто оказался на пути (каждого один раз). */
        private void crush() {
            if (omega < 0.6) return;
            double minX = 1e9, minY = 1e9, minZ = 1e9, maxX = -1e9, maxY = -1e9, maxZ = -1e9;
            List<double[]> centers = new ArrayList<>();
            for (Piece pc : pieces) {
                if (!pc.log) continue;
                double[] c = pos(pc, theta);
                centers.add(c);
                minX = Math.min(minX, c[0]);
                maxX = Math.max(maxX, c[0]);
                minY = Math.min(minY, c[1]);
                maxY = Math.max(maxY, c[1]);
                minZ = Math.min(minZ, c[2]);
                maxZ = Math.max(maxZ, c[2]);
            }
            if (centers.isEmpty()) return;
            AABB area = new AABB(minX - 1.5, minY - 1.5, minZ - 1.5, maxX + 1.5, maxY + 1.5, maxZ + 1.5);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, area)) {
                if (crushed.contains(e.getUUID())) continue;
                AABB eb = e.getBoundingBox();
                for (double[] c : centers) {
                    AABB logBox = new AABB(c[0] - 0.55, c[1] - 0.55, c[2] - 0.55, c[0] + 0.55, c[1] + 0.55, c[2] + 0.55);
                    if (logBox.intersects(eb)) {
                        crushed.add(e.getUUID());
                        e.hurtServer(level, level.damageSources().generic(),
                                CRUSH_BASE + (float) omega * CRUSH_PER_SPEED);
                        level.playSound(null, e.blockPosition(), SoundType.WOOD.getBreakSound(), SoundSource.BLOCKS, 1.5f, 0.6f);
                        break;
                    }
                }
            }
        }

        private void ambience() {
            // шорох кроны на лету
            if (age % 4 == 0) {
                Piece top = pieces.get(pieces.size() - 1);
                double[] c = pos(top, theta);
                BlockPos bp = BlockPos.containing(c[0], c[1], c[2]);
                level.playSound(null, bp, crownSound.getBreakSound(), SoundSource.BLOCKS,
                        (float) Math.min(1.6, 0.4 + omega * 0.4), 0.7f);
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, top.state), c[0], c[1], c[2], 4, 0.5,
                        0.5, 0.5, 0.05);
            }
            if (age % 6 == 1 && theta < 0.5) {
                level.playSound(null, stump, SoundType.WOOD.getHitSound(), SoundSource.BLOCKS, 1.2f, 0.4f);
            }
        }

        /** Приземление: грохот, пыль, куски превращаются в предметы. */
        private void land() {
            level.playSound(null, stump, SoundType.WOOD.getFallSound(), SoundSource.BLOCKS, 3.0f, 0.5f);
            level.playSound(null, stump, SoundType.WOOD.getBreakSound(), SoundSource.BLOCKS, 3.0f, 0.4f);
            BlockState ground = level.getBlockState(stump.below());
            for (Piece pc : pieces) {
                double[] c = pos(pc, theta);
                BlockPos bp = BlockPos.containing(c[0], c[1], c[2]);
                if (pc.log) {
                    Block.popResource(level, bp, new ItemStack(pc.state.getBlock()));
                    level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, ground), c[0], stump.getY() + 0.15,
                            c[2], 5, 0.4, 0.05, 0.4, 0.08);
                    level.sendParticles(ParticleTypes.CLOUD, c[0], stump.getY() + 0.2, c[2], 1, 0.3, 0.05, 0.3, 0.01);
                } else {
                    level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, pc.state), c[0], c[1], c[2], 3, 0.4,
                            0.4, 0.4, 0.05);
                    if (level.getRandom().nextFloat() < 0.12f) Block.popResource(level, bp, new ItemStack(Items.STICK));
                }
                Entity e = level.getEntity(pc.id);
                if (e != null) e.discard();
            }
        }

        /** Для остановки сервера: мгновенно уложить дерево, ничего не теряя. */
        void finishNow() {
            if (displaysOk) {
                theta = Math.PI / 2;
                land();
            }
        }
    }

    // =====================================================================================
    //  Тики: падающие деревья, «заживление» надрубов
    // =====================================================================================

    private static final class Progress {
        final int crackId;
        float hits = 0;
        long lastTick = 0;
        BlockPos lastHit = BlockPos.ZERO;

        Progress(int crackId) {
            this.crackId = crackId;
        }
    }

    private static void tick(MinecraftServer server) {
        for (Iterator<Fall> it = FALLS.iterator(); it.hasNext(); ) {
            if (it.next().tick()) it.remove();
        }

        if (server.getTickCount() % 20 != 0) return;
        for (Iterator<Map.Entry<GlobalPos, Progress>> it = PROGRESS.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<GlobalPos, Progress> en = it.next();
            ServerLevel lvl = server.getLevel(en.getKey().dimension());
            if (lvl == null) {
                it.remove();
                continue;
            }
            Progress pr = en.getValue();
            if (lvl.getGameTime() - pr.lastTick > HEAL_AFTER_TICKS) {
                lvl.destroyBlockProgress(pr.crackId, pr.lastHit, -1);
                it.remove();
            }
        }
        NEXT_HIT_SERVER.values().removeIf(t -> t < server.overworld().getGameTime() - 200);
    }

    private TreeFelling() {}
}
